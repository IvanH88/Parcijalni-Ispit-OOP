<?php
  include_once 'core/init.php';
  
  $db = DB::getInstance();
  dump($db);
  
  